run npm i

then 

run npx expo start
